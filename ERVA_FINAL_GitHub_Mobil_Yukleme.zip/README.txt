ERVA İŞ ELBİSELERİ — V7.3 PREMIUM

Yükleme:
1) Bu ZIP dosyasını açmadan Netlify > erva-is-elbiseleri > Deploys bölümünden yükleyin.
2) Published olduktan sonra siteyi /?v=73 ile açın.
3) Gerekirse /reset.html adresini bir kez açın.

V7.3 yenilikleri:
- Daha premium kurumsal görünüm
- Ana sayfa metinleri kısaltıldı
- Ürün kategori kartları eşitlendi
- İmalatçı firma vurgusu güçlendirildi
- Mobil okunabilirlik iyileştirildi
- Kurumsal üretim avantaj şeridi eklendi
- Footer ve iletişim alanı iyileştirildi
